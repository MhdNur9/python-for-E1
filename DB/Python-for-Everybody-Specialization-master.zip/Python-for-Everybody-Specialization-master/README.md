# Python-for-Everybody-Specialization

In this repository you will find folders containing work I've done for various classes completed through the Python for Everybody specialization on the website Coursera. My purpose in making these files available is in part simply to store them as backups and in part to give potential employers - should they be interested - an idea for the kind of material I've encountered in my programming education thus far. At the time these scripts were created I had been programming for about 6 months.

Some of the files found in these folders are scripts that I completed from scratch and some were completed from "starting point" code.
